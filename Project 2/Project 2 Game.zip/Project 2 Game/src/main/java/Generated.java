/**
 * @author Julius Miguel Bernaudo 994332
 */
import java.util.ArrayList;

public interface Generated {
    int spawn(ArrayList<Peg> pegPos, ArrayList<String> pegType, int totalPegs);
}
